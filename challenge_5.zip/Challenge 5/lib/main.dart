import 'package:flutter/material.dart';

void main() {
  // Envolvemos nuestro widget dentro de un MaterialApp
  runApp(const MaterialApp(
    home: MainScreen(), //Main screen to combine static and dinamic widget
  ));
}

//Principal Screen (General Container)
class MainScreen extends StatelessWidget{
  const MainScreen({super.key});
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
      title: const Text("Stateless y Stateful Together"),
      centerTitle: true,
      ),
      body: Padding(
        //Padding add a space of 16 pixel around the screen
        padding: const EdgeInsets.all(16.0),
        child:Column(
          children: const[
            //Static
            MyStaticCard(),
            //Space
            SizedBox(height: 24),
            //Dinamic
            MyDinamicCard(),

          ],
        )
      )
    );
  }
}



class MyStaticCard extends StatelessWidget {
  const MyStaticCard({super.key});

  @override
  Widget build(BuildContext context) {
    //Use container to give a background color and decorative borders
    return Container(
      //Add Space
      padding: const EdgeInsets.all(16),
      //Use to give color and border
      decoration: BoxDecoration(
        color: Colors.blue.shade100, //background color
        borderRadius: BorderRadius.circular(10)
      ),
      child: const Text(
        "I am a StatelessWidget (do not change the value )",
        style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)
      ),
    );
  }
}

//DINAMIC SHELL
class MyDinamicCard extends StatefulWidget{
  const MyDinamicCard({super.key});
  @override
  State<MyDinamicCard> createState() => _MyDinamicCardState();
}

//The brain of MyDinamicCard, and start with _ to refer a private class

class _MyDinamicCardState extends State<MyDinamicCard>{
  //state variable
  int counterClicks = 0 ;

  @override
  Widget build(BuildContext context){
    //container is like a box
    return Container(
      //inter space in every direction with all
      padding: const EdgeInsets.all(16),
      //Give Style with Box decoration of the container
      decoration: BoxDecoration(
        color: Colors.green.shade100,
        borderRadius: BorderRadius.circular(10)
      ),
      // i can use Column or Row
      child: Column(
        children: [
          const Text("I am StateFulWidget (Dinamic My counter changes)",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)
          ),
          //invisible box
          const SizedBox(height: 10),

          Text(
            "Actual Number: $counterClicks",
            style: const TextStyle(fontSize: 18, color: Colors.green),
          ),

          const SizedBox( height: 10),
          // Like a 3d button using Material Design
          ElevatedButton(
              onPressed: (){
                //Here goes the orders / logic
                setState(() {
                  counterClicks++;
                });
              },
              //The text of the button
              child: const Text("Sum Clicks!"),
          ),
        ],
      )
    );
  }
}
